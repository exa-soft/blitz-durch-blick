var BDB  = (function () {
  // Definiere eine Funktion mit einem Funktionsausdruck,
  // durch runde Klammern umschlossen

  var privateEigenschaft = "privat";

  var rndNumElem;
  var showMs = 150;
  var hideMs = 750;
  var numShows = 3;
  var text = "357";


  function privateMethode ()
  {
    window.alert("privateMethode wurde aufgerufen");
    //window.alert("Private Eigenschaft: " + privateEigenschaft);
    //window.alert("Öffentliche Eigenschaft: " + BDB.öffentlicheEigenschaft);
  }

  function blink() {
    //window.alert("blink wurde aufgerufen");
    rndNumElem.style.display = "block";
    rndNumElem.style.visibility = "hidden";
    numShows = numShows - 1;
    var t1 = setTimeout(showNumberOn, hideMs);
    if (numShows > 0)
      var t2 = setTimeout(blink, hideMs + showMs);
    else
      var t2 = setTimeout(showNumberOff, hideMs + showMs);
  }

  function showNumberOn() {
    //window.alert("showNumberOn wurde aufgerufen");
    rndNumElem.style.visibility = "visible";
  }

  function showNumberOff() {
    //window.alert("showNumberOff wurde aufgerufen");
    rndNumElem.style.visibility = "hidden";
  }


  // Direkt das Object mit der öffentlichen Schnittstelle zurückgeben
  return {
    öffentlicheEigenschaft : "öffentlich",

    öffentlicheMethode1 : function ()
    {
      window.alert("öffentlicheMethode1 wurde aufgerufen");
      /*
      window.alert("Private Eigenschaft: " + privateEigenschaft);
      privateMethode();
      window.alert("Öffentliche Eigenschaft: " + BDB.öffentlicheEigenschaft);
      BDB.öffentlicheMethode2();
      */
      window.setTimeout(privateMethode, 3000);
    },

    öffentlicheMethode2 : function ()
    {
      window.alert("öffentlicheMethode2 wurde aufgerufen");
    },

    init : function ()
    {
      BDB.displayNumber();
    },

    displayNumber : function ()
    {
      //window.alert("displayNumber wurde aufgerufen");

      rndNumElem = document.getElementById("rndNum");
      rndNumElem.innerHTML = text;

      blink();
    },

  };
})();
// Ende des eingeklammerten Funktionsausdrucks, dahinter
// direkt () zum Aufruf der soeben definierten Funktion

//BDB.öffentlicheMethode1();

// Ergibt undefined, weil von außen nicht sichtbar:
//window.alert("Container.privateMethode von außerhalb: " + BDB.privateMethode);
