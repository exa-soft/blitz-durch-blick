var BDB  = (function () {
  // Definiere eine Funktion mit einem Funktionsausdruck,
  // durch runde Klammern umschlossen

  var privateEigenschaft = "privat";

  var elemRndNum;
  var elemIntro;
  var elemGame;
  var elemSettings;

  var numShows = 3;
  var showRepeats = 3;
  var showMs = 150;
  var hideMs = 750;
  var text = "357";


  function privateMethode ()
  {
    window.alert("privateMethode wurde aufgerufen");
    //window.alert("Private Eigenschaft: " + privateEigenschaft);
    //window.alert("Öffentliche Eigenschaft: " + BDB.öffentlicheEigenschaft);
  }

  function getValues ()
  {
    //window.alert("getValues wurde aufgerufen");

    numShows = parseInt(document.getElementById("amount").value);
    showRepeats = parseInt(document.getElementById("repeat").value);
    showMs = parseInt(document.getElementById("showtime").value);
    hideMs = parseInt(document.getElementById("hidetime").value);

    //window.alert("getValues: numShows=" + numShows + ", showRepeats=" + showRepeats
    //  + ", show for " + showMs + "ms, hide for " + hideMs + "ms");

  }

  function displayNumber ()
  {
    //window.alert("displayNumber wurde aufgerufen");

    //elemRndNum = document.getElementById("rndNum");
    elemRndNum.innerHTML = text;
    blink();
  }

  function blink ()
  {
    //window.alert("blink wurde aufgerufen, numShows is " + numShows + ", showRepeats is " + showRepeats);
    elemRndNum.style.display = "block";
    elemRndNum.style.visibility = "hidden";
    //TODO einbauen: Wechsel zum nächsten Bild sofern numShows > 0
    /*
    numShows = numShows - 1;
    if (numShows > 0)
      var t2 = setTimeout(blink, hideMs + showMs);
    else
      var t2 = setTimeout(showNumberOff, hideMs + showMs);
    */

    showRepeats = showRepeats - 1;
    var t1 = setTimeout(showNumberOn, hideMs);
    if (showRepeats > 0)
    {
      //window.alert("showRepeats=" + showRepeats + ", set BDB.blink timeout to " + (hideMs + showMs));
      var t2 = setTimeout(blink, hideMs + showMs);
    }
    else
    {
      //window.alert("showRepeats=" + showRepeats + ", set showNumberOff timeout to " + (hideMs + showMs));
      var t2 = setTimeout(showNumberOff, hideMs + showMs);
    }
  }

  function showNumberOn ()
  {
    //window.alert("showNumberOn wurde aufgerufen");
    elemRndNum.style.visibility = "visible";
  }

  function showNumberOff ()
  {
    //window.alert("showNumberOff wurde aufgerufen");
    elemRndNum.style.visibility = "hidden";
  }


  // Direkt das Object mit der öffentlichen Schnittstelle zurückgeben
  return {
    öffentlicheEigenschaft : "öffentlich",

    öffentlicheMethode1 : function ()
    {
      window.alert("öffentlicheMethode1 wurde aufgerufen");
      /*
      window.alert("Private Eigenschaft: " + privateEigenschaft);
      privateMethode();
      window.alert("Öffentliche Eigenschaft: " + BDB.öffentlicheEigenschaft);
      BDB.öffentlicheMethode2();
      */
      window.setTimeout(privateMethode, 3000);
    },

    öffentlicheMethode2 : function ()
    {
      window.alert("öffentlicheMethode2 wurde aufgerufen");
    },

    init : function ()
    {
      //window.alert("init wurde aufgerufen");

      elemRndNum = document.getElementById("rndNum");
      elemIntro = document.getElementById("intro");
      elemGame = document.getElementById("game");
      elemSettings = document.getElementById("settings");

      //document.getElementById("startGame").onclick = BDB.displayNumber();
      return null;
    },

    startGame : function ()
    {
      getValues ();

      // TODO generate randum number(s) into array

      BDB.displayGameOnly ();
      displayNumber ();
      //BDB.displaySettingsOnly ();
    },

    displayIntroOnly : function ()
    {
      elemIntro.style.display = "block";
      elemSettings.style.display = "none";
      elemGame.style.display = "none";
    },

    displaySettingsOnly : function ()
    {
      elemIntro.style.display = "none";
      elemSettings.style.display = "block";
      elemGame.style.display = "none";
    },

    displayGameOnly : function ()
    {
      elemIntro.style.display = "none";
      elemSettings.style.display = "none";
      elemGame.style.display = "block";
    },


  };
})();
// Ende des eingeklammerten Funktionsausdrucks, dahinter
// direkt () zum Aufruf der soeben definierten Funktion

//BDB.öffentlicheMethode1();

// Ergibt undefined, weil von außen nicht sichtbar:
//window.alert("Container.privateMethode von außerhalb: " + BDB.privateMethode);
